using namespace System.Net

param($Request, $TriggerMetadata)

# Get user email from query string
$userEmail = $Request.Query.user

if (-not $userEmail) {
    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
        StatusCode = [HttpStatusCode]::BadRequest
        Body = "Missing user parameter"
    })
    return
}

Write-Host "Processing MFA click tracking for user: $userEmail"

try {
    # Get access token using Connect-AzAccount with Managed Identity
    Connect-AzAccount -Identity -ErrorAction Stop
    $token = (Get-AzAccessToken -ResourceUrl "https://graph.microsoft.com").Token
    
    # Get configuration from environment variables (set from INI file)
    $groupId = $env:MFA_GROUP_ID
    $siteUrl = $env:SHAREPOINT_SITE_URL
    $listId = $env:SHAREPOINT_LIST_ID
    
    if (-not $groupId) {
        throw "MFA_GROUP_ID environment variable not set"
    }
    if (-not $siteUrl) {
        throw "SHAREPOINT_SITE_URL environment variable not set"
    }
    if (-not $listId) {
        throw "SHAREPOINT_LIST_ID environment variable not set"
    }
    
    Write-Host "Configuration loaded from environment variables"
    Write-Host "  Group ID: $groupId"
    Write-Host "  Site URL: $siteUrl"
    Write-Host "  List ID: $listId"

    # Get user ID from email
    $userResponse = Invoke-RestMethod -Uri "https://graph.microsoft.com/v1.0/users/$userEmail" -Headers @{
        Authorization = "Bearer $token"
    } -Method Get

    $userId = $userResponse.id
    Write-Host "Found user ID: $userId"

    # Add user to MFA Registration group
    $addedToGroup = $false
    $alreadyInGroup = $false
    try {
        $addMemberBody = @{
            "@odata.id" = "https://graph.microsoft.com/v1.0/directoryObjects/$userId"
        } | ConvertTo-Json

        Invoke-RestMethod -Uri "https://graph.microsoft.com/v1.0/groups/$groupId/members/`$ref" -Headers @{
            Authorization = "Bearer $token"
            "Content-Type" = "application/json"
        } -Method Post -Body $addMemberBody

        Write-Host "Successfully added user to MFA Registration group"
        $addedToGroup = $true
    }
    catch {
        # User might already be in group - that's okay
        if ($_.Exception.Response.StatusCode -eq 400) {
            Write-Host "User already in group (this is fine)"
            $alreadyInGroup = $true
            $addedToGroup = $true  # Treat as success for SharePoint update
        }
        else {
            Write-Host "Error adding to group: $_"
        }
    }

    # Update SharePoint list with ClickedLinkDate and GroupAdded status
    try {
        Write-Host "Updating SharePoint list..."
        
        # Extract site path from URL for Graph API
        $siteUri = [System.Uri]$siteUrl
        $siteDomain = $siteUri.Host
        $sitePath = $siteUri.AbsolutePath  # e.g., /sites/MFAOps
        
        # Get the list item for this user
        $listItemsUrl = "https://graph.microsoft.com/v1.0/sites/$($siteDomain):$($sitePath):/lists/$listId/items?`$filter=fields/Title eq '$userEmail'&`$expand=fields"
        $listItems = Invoke-RestMethod -Uri $listItemsUrl -Headers @{
            Authorization = "Bearer $token"
        } -Method Get
        
        if ($listItems.value.Count -gt 0) {
            $itemId = $listItems.value[0].id
            $updateUrl = "https://graph.microsoft.com/v1.0/sites/$($siteDomain):$($sitePath):/lists/$listId/items/$itemId/fields"
            
            # Prepare update body with timestamp and group status
            # Keep InviteStatus as "Sent" so Logic App can monitor MFA activation
            $currentTime = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ssZ")
            $updateBody = @{
                ClickedLinkDate = $currentTime
                InGroup = $addedToGroup
                AddedToGroupDate = if ($addedToGroup) { $currentTime } else { $null }
                InviteStatus = "Sent"
            } | ConvertTo-Json
            
            Invoke-RestMethod -Uri $updateUrl -Headers @{
                Authorization = "Bearer $token"
                "Content-Type" = "application/json"
            } -Method Patch -Body $updateBody
            
            Write-Host "Successfully updated SharePoint list:"
            Write-Host "  - ClickedLinkDate: $currentTime"
            Write-Host "  - InGroup: $(if ($addedToGroup) { 'True' } else { 'False' })"
            Write-Host "  - AddedToGroupDate: $(if ($addedToGroup) { $currentTime } else { 'Not set' })"
            Write-Host "  - InviteStatus: Sent (kept for Logic App monitoring)"
        }
        else {
            Write-Host "Warning: User not found in SharePoint list"
        }
    }
    catch {
        Write-Host "Warning: Could not update SharePoint (non-critical): $_"
        Write-Host "Error details: $($_.Exception.Message)"
    }

    # Display success page with auto-redirect to Microsoft MFA setup
    $successMessage = if ($alreadyInGroup) {
        "You're already registered! Redirecting to MFA setup..."
    } else {
        "Successfully added to MFA Registration group!"
    }
    
    $htmlResponse = @"
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MFA Registration - Processing</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 40px;
            max-width: 500px;
            width: 100%;
            text-align: center;
            animation: slideIn 0.5s ease-out;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
            animation: pulse 2s ease-in-out infinite;
        }
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        .icon svg {
            width: 40px;
            height: 40px;
            fill: white;
        }
        h1 {
            color: #2d3748;
            font-size: 28px;
            margin-bottom: 16px;
            font-weight: 600;
        }
        .user-email {
            color: #667eea;
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 24px;
            word-break: break-all;
        }
        .status {
            background: #f0fdf4;
            border: 2px solid #86efac;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 24px;
        }
        .status p {
            color: #166534;
            font-size: 16px;
            line-height: 1.5;
        }
        .redirect-info {
            color: #64748b;
            font-size: 14px;
            margin-top: 20px;
        }
        .spinner {
            border: 3px solid #f3f4f6;
            border-top: 3px solid #667eea;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
            </svg>
        </div>
        <h1>$successMessage</h1>
        <div class="user-email">$userEmail</div>
        <div class="status">
            <p><strong>✓ Added to MFA Registration Group</strong></p>
            <p>You can now set up Multi-Factor Authentication</p>
        </div>
        <div class="spinner"></div>
        <p class="redirect-info">Redirecting to Microsoft MFA setup page in 3 seconds...</p>
    </div>
    <script>
        setTimeout(function() {
            window.location.href = 'https://aka.ms/mfasetup';
        }, 3000);
    </script>
</body>
</html>
"@

    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
        StatusCode = [HttpStatusCode]::OK
        Headers = @{
            "Content-Type" = "text/html; charset=utf-8"
        }
        Body = $htmlResponse
    })

    Write-Host "Successfully processed click tracking for $userEmail"
}
catch {
    Write-Host "ERROR: $_"
    Write-Host "Error Details: $($_.Exception.Message)"
    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
        StatusCode = [HttpStatusCode]::InternalServerError
        Body = "Error processing request: $($_.Exception.Message)"
    })
}
















